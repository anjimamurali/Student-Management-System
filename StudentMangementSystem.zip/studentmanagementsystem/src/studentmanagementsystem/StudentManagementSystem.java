package studentmanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;


class Student {
    private int id;
    private String name;
    private int age;
    private String grade;
    private int attendance;

    public Student(int id, String name, int age, String grade) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
        this.attendance = 0;
    }

    public int getId() {
        return id;
    }

    public void markAttendance() {
        attendance++;
    }

    public void updateGrade(String grade) {
        this.grade = grade;
    }

    public void displayStudent() {
        System.out.println("------ Student Info ------");
        System.out.println("ID       : " + id);
        System.out.println("Name     : " + name);
        System.out.println("Age      : " + age);
        System.out.println("Grade    : " + grade);
        System.out.println("Attendance Count: " + attendance);
        System.out.println("--------------------------");
    }
}


public class StudentManagementSystem {
    private static ArrayList<Student> students = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int idCounter = 1;

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            System.out.println("\n====== Student Management System ======");
            System.out.println("1. Enroll Student");
            System.out.println("2. View All Students");
            System.out.println("3. Mark Attendance");
            System.out.println("4. Update Grade");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear input buffer

            switch (choice) {
                case 1:
                    enrollStudent();
                    break;
                case 2:
                    viewStudents();
                    break;
                case 3:
                    markAttendance();
                    break;
                case 4:
                    updateGrade();
                    break;
                case 5:
                    running = false;
                    System.out.println("System closed.");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void enrollStudent() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter grade: ");
        String grade = scanner.nextLine();

        Student student = new Student(idCounter++, name, age, grade);
        students.add(student);

        System.out.println("Student enrolled successfully!");
    }

    private static void viewStudents() {
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            for (Student s : students) {
                s.displayStudent();
            }
        }
    }

    private static void markAttendance() {
        System.out.print("Enter student ID to mark attendance: ");
        int id = scanner.nextInt();

        Student student = findStudentById(id);
        if (student != null) {
            student.markAttendance();
            System.out.println("Attendance marked for student ID: " + id);
        } else {
            System.out.println("Student not found.");
        }
    }

    private static void updateGrade() {
        System.out.print("Enter student ID to update grade: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Student student = findStudentById(id);
        if (student != null) {
            System.out.print("Enter new grade: ");
            String grade = scanner.nextLine();
            student.updateGrade(grade);
            System.out.println("Grade updated.");
        } else {
            System.out.println("Student not found.");
        }
    }

    private static Student findStudentById(int id) {
        for (Student s : students) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }
}
